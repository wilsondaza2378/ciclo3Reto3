package co.usa.cliclo3.reto3.crud;

import co.usa.cliclo3.reto3.model.Score;
import org.springframework.data.repository.CrudRepository;

public interface ScoreCrudRepository extends CrudRepository<Score, Integer> {
}
